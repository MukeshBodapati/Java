package com.contact.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ContactDAO {
    private static final Map<String, Contact> cnctMap = new HashMap<String, Contact>();
    
    static {
    	initCncts();
    }

	private static void initCncts() {
		// TODO Auto-generated method stub
		Contact cnct1 = new Contact("Mukesh", "mukesh@gmail.com", "7075868876");
		Contact cnct2 = new Contact("Saketh", "saketh@yahoo.com", "7975852876");
		Contact cnct3 = new Contact("Sai Kumar", "dinu@gmail.com", "7893264876");
		Contact cnct4 = new Contact("Sumanth", "sumanth@gmail.com", "9385865976");
		Contact cnct5 = new Contact("Naidu", "naidu3@gmail.com", "9492258534");
		Contact cnct6 = new Contact("Bommidi", "bommidi@gmail.com", "7075431876");
		Contact cnct7 = new Contact("Khadar", "abdul831@gmail.com", "9581428876");
		
		cnctMap.put(cnct1.getCnctName(), cnct1);
		cnctMap.put(cnct2.getCnctName(), cnct2);
		cnctMap.put(cnct3.getCnctName(), cnct3);
		cnctMap.put(cnct4.getCnctName(), cnct4);
		cnctMap.put(cnct5.getCnctName(), cnct5);
		cnctMap.put(cnct6.getCnctName(), cnct6);
		cnctMap.put(cnct7.getCnctName(), cnct7);
	}
	
	public static List<Contact> getContact(String cnctName) {
		List<Contact> list = new ArrayList<Contact>();
		
		list.add(cnctMap.get(cnctName));
		return list;
	}
	public static Contact addContact(Contact cnct) {
		cnctMap.put(cnct.getCnctName(), cnct);
		return cnct;
	}
	public static Contact modifyContact(Contact cnct) {
		cnctMap.put(cnct.getCnctName(), cnct);
		return cnct;
	}
	public static void deleteContact(String cnctName) {
		cnctMap.remove(cnctName);
	}
	public static List<Contact> getAllContacts() {
		Collection<Contact> c = cnctMap.values();
		List<Contact> list = new ArrayList<Contact>();
		list.addAll(c);
		return list;
	}
	List<Contact> list;
}
