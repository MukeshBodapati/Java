import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Contact } from './contact';
@Injectable({
  providedIn: 'root'
})
export class ContactServiceService {

  constructor(private http: HttpClient) { }

  getContacts() {
    let url =  'http://localhost:8080/ContactProject/rest/contacts';
    return this.http.get(url);
  }
  viewContact(cnctName: string) {
    let url = 'http://localhost:8080/ContactProject/rest/contacts/';
    return this.http.get(url+cnctName);
 }
  addContact(contact: Contact) {
    let url = 'http://localhost:8080/ContactProject/rest/contacts/add';
    return this.http.post(url,contact);
  }
  modifyContact(contact: Contact){
    let url = 'http://localhost:8080/ContactProject/rest/contacts/modify';
    return this.http.put(url, contact);
  }
  deleteContact(cnctName: string) {
    let url = 'http://localhost:8080/ContactProject/rest/contacts/';
    return this.http.delete(url+cnctName);
  }
}