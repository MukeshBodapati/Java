import { Component, OnInit } from '@angular/core';
import { ContactServiceService } from '../contact-service.service';
import { ViewAllContactsComponent } from '../view-all-contacts/view-all-contacts.component';

@Component({
  selector: 'app-delete-contact',
  templateUrl: './delete-contact.component.html',
  styleUrls: ['./delete-contact.component.css']
})
export class DeleteContactComponent implements OnInit {
  nametodelete: string
  

  constructor(private service: ContactServiceService) { }

  ngOnInit(): void {
  }
  deleteContact() {
    this.service.deleteContact(this.nametodelete).subscribe(data => {
     //  alert(JSON.stringify(data));
      // alert(data);
     // console.log(this.nametodelete);
      console.log(data);
      if(data ==null) {
        alert("Deleted Successfully");
      }
     
    });
  }
}
