import { Component, OnInit } from '@angular/core';
import { ContactServiceService } from '../contact-service.service';

import { Contact } from '../contact';

@Component({
  selector: 'app-view-contact',
  templateUrl: './view-contact.component.html',
  styleUrls: ['./view-contact.component.css']
})
export class ViewContactComponent implements OnInit {

  nametosearch: string;
  contacts: any;
  constructor(private service: ContactServiceService) { }
     // lstcontact: Contact[];
     // nametosearch: string;
  
  viewContact() {
    this.service.viewContact(this.nametosearch).subscribe(data => {
      this.contacts =data;
      console.log(data);
      
   })
  }
    
  ngOnInit(): void {
    //this.service.getContact(this.nametosearch).subscribe(data=>{
    //  this.lstcontact=data;
   // })

  }
  
}
