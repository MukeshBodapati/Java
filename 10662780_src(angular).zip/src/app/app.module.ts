import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ViewAllContactsComponent } from './view-all-contacts/view-all-contacts.component';
import { ViewContactComponent } from './view-contact/view-contact.component';
import { AddContactComponent } from './add-contact/add-contact.component';
import { ModifyContactComponent } from './modify-contact/modify-contact.component';
import { DeleteContactComponent } from './delete-contact/delete-contact.component';
import { HttpClientModule } from '@angular/common/http';
import { ContactServiceService } from './contact-service.service';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    ViewAllContactsComponent,
    ViewContactComponent,
    AddContactComponent,
    ModifyContactComponent,
    DeleteContactComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [ContactServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
