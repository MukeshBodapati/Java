import { Component, OnInit } from '@angular/core';
import { Contact } from '../contact';
import { ContactServiceService } from '../contact-service.service';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',

  styleUrls: ['./add-contact.component.css']
})
export class AddContactComponent implements OnInit {
  con: Contact=new Contact();
 
  constructor(private service: ContactServiceService) { 
    this.con.cnctName='yesh';
    this.con.email='yesh6@gmail.com';
    this.con.phoNum='9494067543';
  }
  
  ngOnInit(): void {
  }
  addContacts() {
    alert(JSON.stringify(this.con));
    this.service.addContact(this.con).subscribe(data =>{
      alert(JSON.stringify(data))
      alert(data);
      console.groupCollapsed(data);
      if(data !=null) {
        alert("Added Successfully");
      }
    });
  }
}
