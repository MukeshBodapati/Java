import { Component, OnInit } from '@angular/core';
import { Contact } from '../contact';
import { ContactServiceService } from '../contact-service.service';

@Component({
  selector: 'app-modify-contact',
  templateUrl: './modify-contact.component.html',
  styleUrls: ['./modify-contact.component.css']
})
export class ModifyContactComponent implements OnInit {
  con: Contact = new Contact();

  constructor(private service: ContactServiceService) {
    this.con.cnctName;
    this.con.email;
    this.con.phoNum;
   }

  ngOnInit(): void {
  }
  modifyContact() {
    alert(JSON.stringify(this.con));
    this.service.modifyContact(this.con).subscribe(data => {
      alert(JSON.stringify(data))
      alert(data);
      console.groupCollapsed(data);
      if(data !=null) {
        alert("Saved Successfully");
      }
    });
  }
}
