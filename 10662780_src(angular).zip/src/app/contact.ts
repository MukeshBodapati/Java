export class Contact {
    cnctName: string;
    email: string;
    phoNum: string;
}