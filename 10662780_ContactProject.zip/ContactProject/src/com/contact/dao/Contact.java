package com.contact.dao;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "contacts")
public class Contact {
		private String cnctName;
		private String email;
		private String phoNum;
		
		public Contact() {
			
		}
		public Contact(String cnctName, String email, String phoNum) {
			this.cnctName = cnctName;
			this.email = email;
			this.phoNum = phoNum;
		}
		public String getCnctName() {
			return cnctName;
		}
		@XmlElement
		public void  setCnctName(String cnctName) {
			this.cnctName = cnctName;
		}
		public String getEmail() {
			return email;
		}
		@XmlElement
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPhoNum() {
			return phoNum;
		}
		@XmlElement
		public void setPhoNum(String phoNum) {
			this.phoNum = phoNum;
		}
}
