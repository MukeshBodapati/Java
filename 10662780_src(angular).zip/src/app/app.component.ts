import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { ContactServiceService } from './contact-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ContactProject';
  constructor(private css:ContactServiceService,private myhttp: HttpClient)
  {
    this.css.getContacts
  }
  ngOnInit(){
    this.myhttp.get('http://localhost:8080/ContactProject/rest/contacts').
    subscribe((dataFromNet)=>this.displayData(dataFromNet));
  }
  thisPageGlobalData;

  displayData(dataFromNet){
    this.thisPageGlobalData = dataFromNet;
  }
}
