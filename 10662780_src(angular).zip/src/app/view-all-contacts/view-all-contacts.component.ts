import { Component, OnInit } from '@angular/core';
import { ContactServiceService } from '../contact-service.service';

@Component({
  selector: 'app-view-all-contacts',
  templateUrl: './view-all-contacts.component.html',
  styleUrls: ['./view-all-contacts.component.css']
})
export class ViewAllContactsComponent implements OnInit {
    contacts: any;

  constructor(private service: ContactServiceService) { 
    
  }
  ngOnInit(): void {
    this.service.getContacts().subscribe(data =>{
      this.contacts=data;
    })
  }
  viewAll() {
    this.service.getContacts().subscribe(data =>{
      this.contacts=data;
      console.log(data)
    })
  }
}
